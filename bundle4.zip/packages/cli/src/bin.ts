// packages/cli/src/bin.ts
import { run } from "./cli";

process.exitCode = run(process.argv.slice(2), {
  out: (t) => console.log(t),
  err: (t) => console.error(t),
});

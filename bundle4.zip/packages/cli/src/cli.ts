// packages/cli/src/cli.ts
// Argument handling for the `arch` command. Returns an exit code instead of
// calling process.exit, so it can be tested.
import { runCheck, UsageError } from "./check";
import { formatJson, formatText } from "./format";

export interface Io {
  out: (text: string) => void;
  err: (text: string) => void;
}

export const HELP = `arch - keep AI-written code inside your architecture

Usage:
  arch check [--root <dir>] [--constitution <file>] [--format text|json]

Exit codes: 0 = no errors, 1 = rule violations, 2 = usage or configuration error.`;

export interface ParsedArgs {
  command: string | undefined;
  root: string;
  constitution: string | undefined;
  format: "text" | "json";
}

export function parseArgs(argv: ReadonlyArray<string>): ParsedArgs {
  const out: ParsedArgs = { command: undefined, root: ".", constitution: undefined, format: "text" };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]!;
    const value = (): string => {
      const v = argv[++i];
      if (v === undefined) throw new UsageError(`${a} needs a value`);
      return v;
    };
    if (a === "--root") out.root = value();
    else if (a === "--constitution") out.constitution = value();
    else if (a === "--format") {
      const f = value();
      if (f !== "text" && f !== "json") throw new UsageError(`--format must be text or json, not "${f}"`);
      out.format = f;
    } else if (a.startsWith("-")) throw new UsageError(`unknown option ${a}`);
    else if (out.command === undefined) out.command = a;
    else throw new UsageError(`unexpected argument ${a}`);
  }
  return out;
}

export function run(argv: ReadonlyArray<string>, io: Io): number {
  try {
    if (argv.includes("--help") || argv.includes("-h") || argv.length === 0) {
      io.out(HELP);
      return 0;
    }
    const args = parseArgs(argv);
    if (args.command !== "check") {
      throw new UsageError(`unknown command "${args.command ?? ""}". Try: arch check`);
    }
    const result = runCheck(args.root, args.constitution);
    io.out(args.format === "json" ? formatJson(result) : formatText(result));
    return result.failed ? 1 : 0;
  } catch (e) {
    if (e instanceof UsageError) {
      io.err(`arch: ${e.message}`);
      return 2;
    }
    throw e;
  }
}

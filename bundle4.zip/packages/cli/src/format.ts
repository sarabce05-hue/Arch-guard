// packages/cli/src/format.ts
// Turns a CheckResult into text for humans or JSON for tools. Pure.
import type { CheckResult } from "./check";

export function formatJson(result: CheckResult): string {
  return JSON.stringify(
    { ...result.report, unassigned: result.unassigned, unresolved: result.unresolved },
    null,
    2,
  );
}

export function formatText(result: CheckResult): string {
  const { report } = result;
  const lines: string[] = [];

  for (const v of report.violations) {
    const where = v.line ? `${v.file}:${v.line}` : v.file;
    lines.push(`${v.severity === "error" ? "ERROR" : "warn "} ${where}  [${v.ruleId}]`);
    lines.push(`  ${v.message}`);
    lines.push(`  fix: ${v.fixHint}`);
    lines.push("");
  }

  const errors = report.violations.filter((v) => v.severity === "error").length;
  const warns = report.violations.length - errors;
  lines.push(
    `Checked ${report.analyzedFiles} files: ${errors} error${errors === 1 ? "" : "s"}, ${warns} warning${warns === 1 ? "" : "s"}.`,
  );

  if (result.unassigned.length > 0) {
    lines.push(`Note: ${result.unassigned.length} file(s) belong to no module and are not checked:`);
    for (const f of result.unassigned.slice(0, 10)) lines.push(`  - ${f}`);
    if (result.unassigned.length > 10) lines.push(`  ... and ${result.unassigned.length - 10} more`);
  }
  if (result.unresolved.length > 0) {
    lines.push(`Note: ${result.unresolved.length} import(s) point at files that do not exist:`);
    for (const u of result.unresolved.slice(0, 10)) lines.push(`  - ${u.file}:${u.line} imports "${u.specifier}"`);
  }
  if (report.unverifiedInvariants.length > 0) {
    lines.push(`Note: invariants without an automatic check: ${report.unverifiedInvariants.join(", ")}`);
  }
  lines.push(result.failed ? "FAILED" : "OK");
  return lines.join("\n");
}

// packages/cli/src/check.ts
// `arch check`: read the Constitution, analyze the project, verify the rules.
// The CLI holds no rule logic; it only wires the other packages together.
import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { parse } from "yaml";
import { analyzeProject } from "@arch/analyzer";
import { parseConstitution, type CheckReport, type Constitution } from "@arch/spec";
import { hasErrors, verify } from "@arch/verifier";

export const DEFAULT_CONSTITUTION = ".arch/constitution.yaml";

/** A problem the user must fix before checking can run (bad file, bad YAML...). */
export class UsageError extends Error {}

export interface CheckResult {
  report: CheckReport;
  /** Code files that belong to no module of the Constitution. */
  unassigned: string[];
  /** Relative imports that point at nothing. */
  unresolved: Array<{ file: string; specifier: string; line: number }>;
  failed: boolean;
}

export function loadConstitution(root: string, file = DEFAULT_CONSTITUTION): Constitution {
  const path = resolve(root, file);
  if (!existsSync(path)) {
    throw new UsageError(`Constitution not found: ${file} (looked in ${root})`);
  }
  let data: unknown;
  try {
    data = parse(readFileSync(path, "utf8"));
  } catch (e) {
    throw new UsageError(`${file} is not valid YAML: ${(e as Error).message}`);
  }
  const result = parseConstitution(data);
  if (!result.ok) {
    throw new UsageError(
      `${file} is not a valid Constitution:\n` + result.errors.map((m) => `  - ${m}`).join("\n"),
    );
  }
  return result.value;
}

export function runCheck(root: string, constitutionFile?: string): CheckResult {
  const absRoot = resolve(root);
  const constitution = loadConstitution(absRoot, constitutionFile);
  const { graph, modules } = analyzeProject(absRoot, constitution.modules);
  const report = verify({
    constitution,
    files: graph.files,
    edges: graph.edges,
    fileModules: modules?.fileModules ?? {},
  });
  return {
    report,
    unassigned: modules?.unassigned ?? [],
    unresolved: graph.unresolved,
    failed: hasErrors(report),
  };
}


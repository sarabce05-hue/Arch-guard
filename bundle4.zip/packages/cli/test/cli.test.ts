import { describe, it, expect } from "vitest";
import { mkdtempSync, mkdirSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { parseArgs, run } from "../src/cli";
import { analyzeProject } from "@arch/analyzer";
import { loadConstitution, runCheck } from "../src/check";

function project(files: Record<string, string>): string {
  const root = mkdtempSync(join(tmpdir(), "arch-cli-"));
  for (const [p, c] of Object.entries(files)) {
    mkdirSync(join(root, p, ".."), { recursive: true });
    writeFileSync(join(root, p), c);
  }
  return root;
}

const CONSTITUTION = `
version: 1
modules:
  - { id: ui, path: "src/ui" }
  - { id: db, path: "src/db" }
rules:
  - { id: ui-no-db, type: deny, from: ui, to: db, message: "UI must not touch the database." }
`;

function capture() {
  const out: string[] = [];
  const err: string[] = [];
  return { io: { out: (t: string) => out.push(t), err: (t: string) => err.push(t) }, out, err };
}

describe("parseArgs", () => {
  it("reads command and options", () => {
    expect(parseArgs(["check", "--root", "x", "--format", "json"])).toEqual({
      command: "check", root: "x", constitution: undefined, format: "json",
    });
  });
});

describe("arch check", () => {
  const bad = project({
    ".arch/constitution.yaml": CONSTITUTION,
    "src/ui/page.ts": `import { q } from "../db/query";\nexport const p = q;`,
    "src/db/query.ts": `export const q = 1;`,
    "src/stray.ts": `export const s = 1;`,
  });
  const good = project({
    ".arch/constitution.yaml": CONSTITUTION,
    "src/ui/page.ts": `export const p = 1;`,
    "src/db/query.ts": `import { p } from "../ui/page";\nexport const q = p;`,
  });

  it("exits 1 and explains a violation", () => {
    const c = capture();
    expect(run(["check", "--root", bad], c.io)).toBe(1);
    const text = c.out.join("\n");
    expect(text).toContain("src/ui/page.ts:1");
    expect(text).toContain("ui-no-db");
    expect(text).toContain("UI must not touch the database.");
    expect(text).toContain("fix:");
    expect(text).toContain("src/stray.ts");
    expect(text).toContain("FAILED");
  });
  it("exits 0 when the rules hold", () => {
    const c = capture();
    expect(run(["check", "--root", good], c.io)).toBe(0);
    expect(c.out.join("\n")).toContain("OK");
  });
  it("prints JSON that tools can read", () => {
    const c = capture();
    run(["check", "--root", bad, "--format", "json"], c.io);
    const data = JSON.parse(c.out.join("\n"));
    expect(data.violations.length).toBe(1);
    expect(data.violations[0].ruleId).toBe("ui-no-db");
  });
  it("exits 2 when the Constitution is missing or invalid", () => {
    const empty = project({ "src/a.ts": "export {}" });
    const c1 = capture();
    expect(run(["check", "--root", empty], c1.io)).toBe(2);
    expect(c1.err.join("\n")).toContain("not found");

    const broken = project({ ".arch/constitution.yaml": "version: 2\nmodules: []" });
    const c2 = capture();
    expect(run(["check", "--root", broken], c2.io)).toBe(2);
    expect(c2.err.join("\n")).toContain("not a valid Constitution");
  });
  it("exits 2 for unknown commands and options", () => {
    expect(run(["frobnicate"], capture().io)).toBe(2);
    expect(run(["check", "--nope"], capture().io)).toBe(2);
    expect(run(["check", "--format", "xml"], capture().io)).toBe(2);
  });
  it("shows help", () => {
    const c = capture();
    expect(run(["--help"], c.io)).toBe(0);
    expect(c.out.join("\n")).toContain("Usage:");
  });
});

describe("dogfooding: this repository obeys its own Constitution", () => {
  // Tests run from packages/cli, so the repo root is two levels up.
  const root = join(process.cwd(), "../..");
  it("has no rule violations of severity error", () => {
    const result = runCheck(root);
    expect(result.report.violations.filter((v) => v.severity === "error")).toEqual([]);
  });
  it("sees the real dependencies between packages", () => {
    const { modules } = analyzeProject(root, loadConstitution(root).modules);
    const pairs = new Set(modules!.edges.map((e) => `${e.fromModule}->${e.toModule}`));
    expect(pairs.has("verifier->spec")).toBe(true);
    expect(pairs.has("cli->analyzer")).toBe(true);
    expect(pairs.has("cli->verifier")).toBe(true);
  });
});

// packages/analyzer/src/graph.ts
// Builds the file-level dependency graph from a list of files. Pure.
import { extractImports, type ImportKind } from "./imports";
import { resolveImport, type ResolveOptions } from "./resolve";

export interface SourceFile {
  /** Path relative to the project root, with forward slashes. */
  path: string;
  content: string;
}

export interface Edge {
  from: string;
  to: string;
  specifier: string;
  line: number;
  kind: ImportKind;
  typeOnly: boolean;
}

export interface ExternalUse {
  file: string;
  /** Package name, e.g. "react" or "@supabase/supabase-js". */
  name: string;
  line: number;
  typeOnly: boolean;
}

export interface UnresolvedImport {
  file: string;
  specifier: string;
  line: number;
}

export interface FileGraph {
  /** Code files that were parsed, sorted. */
  files: string[];
  edges: Edge[];
  externals: ExternalUse[];
  unresolved: UnresolvedImport[];
}

export const CODE_FILE = /\.(ts|tsx|js|jsx|mjs|cjs|mts|cts)$/i;

export function normalizePath(p: string): string {
  return p.replace(/\\/g, "/").replace(/^\.\//, "");
}

export function buildFileGraph(
  input: ReadonlyArray<SourceFile>,
  options: ResolveOptions = {},
): FileGraph {
  const sources = input.map((f) => ({ ...f, path: normalizePath(f.path) }));
  // Every known file can be an import target (including .json), but only
  // code files are parsed.
  const known = new Set(sources.map((f) => f.path));

  const files: string[] = [];
  const edges: Edge[] = [];
  const externals: ExternalUse[] = [];
  const unresolved: UnresolvedImport[] = [];

  for (const file of sources) {
    if (!CODE_FILE.test(file.path)) continue;
    files.push(file.path);

    for (const ref of extractImports(file.path, file.content)) {
      const result = resolveImport(file.path, ref.specifier, known, options);
      if (result.kind === "file") {
        edges.push({
          from: file.path,
          to: result.path,
          specifier: ref.specifier,
          line: ref.line,
          kind: ref.kind,
          typeOnly: ref.typeOnly,
        });
      } else if (result.kind === "external") {
        externals.push({
          file: file.path,
          name: result.name,
          line: ref.line,
          typeOnly: ref.typeOnly,
        });
      } else {
        unresolved.push({
          file: file.path,
          specifier: ref.specifier,
          line: ref.line,
        });
      }
    }
  }

  const byPathThenLine = <T extends { line: number }>(
    key: (x: T) => string,
  ) => (a: T, b: T) => {
    const k = key(a).localeCompare(key(b));
    return k !== 0 ? k : a.line - b.line;
  };

  files.sort();
  edges.sort(byPathThenLine((e) => `${e.from}\0${e.to}`));
  externals.sort(byPathThenLine((e) => `${e.file}\0${e.name}`));
  unresolved.sort(byPathThenLine((u) => `${u.file}\0${u.specifier}`));

  return { files, edges, externals, unresolved };
}

// packages/analyzer/src/imports.ts
// Extracts the imports of one TS/JS file. Pure: takes text, returns data.
import ts from "typescript";

export type ImportKind = "import" | "export-from" | "dynamic" | "require";

export interface ImportRef {
  /** The text between the quotes, e.g. "./db" or "react". */
  specifier: string;
  kind: ImportKind;
  /** True when the import only exists for types and disappears at runtime. */
  typeOnly: boolean;
  /** 1-based line where the statement starts. */
  line: number;
}

function scriptKindFor(fileName: string): ts.ScriptKind {
  const lower = fileName.toLowerCase();
  if (lower.endsWith(".tsx")) return ts.ScriptKind.TSX;
  if (lower.endsWith(".jsx")) return ts.ScriptKind.JSX;
  if (/\.(js|mjs|cjs)$/.test(lower)) return ts.ScriptKind.JS;
  return ts.ScriptKind.TS;
}

// `import type { A } from "x"` and `import { type A, type B } from "x"`
function isTypeOnlyImport(node: ts.ImportDeclaration): boolean {
  const clause = node.importClause;
  if (!clause) return false;
  if (clause.isTypeOnly) return true;
  const named = clause.namedBindings;
  return (
    !clause.name &&
    named !== undefined &&
    ts.isNamedImports(named) &&
    named.elements.length > 0 &&
    named.elements.every((e) => e.isTypeOnly)
  );
}

export function extractImports(fileName: string, content: string): ImportRef[] {
  const sf = ts.createSourceFile(
    fileName,
    content,
    ts.ScriptTarget.Latest,
    true,
    scriptKindFor(fileName),
  );
  const refs: ImportRef[] = [];

  const add = (
    specifier: string,
    kind: ImportKind,
    typeOnly: boolean,
    node: ts.Node,
  ) => {
    const line = sf.getLineAndCharacterOfPosition(node.getStart(sf)).line + 1;
    refs.push({ specifier, kind, typeOnly, line });
  };

  const visit = (node: ts.Node): void => {
    if (
      ts.isImportDeclaration(node) &&
      ts.isStringLiteral(node.moduleSpecifier)
    ) {
      add(node.moduleSpecifier.text, "import", isTypeOnlyImport(node), node);
    } else if (
      ts.isExportDeclaration(node) &&
      node.moduleSpecifier &&
      ts.isStringLiteral(node.moduleSpecifier)
    ) {
      add(node.moduleSpecifier.text, "export-from", node.isTypeOnly, node);
    } else if (
      ts.isImportEqualsDeclaration(node) &&
      ts.isExternalModuleReference(node.moduleReference) &&
      ts.isStringLiteral(node.moduleReference.expression)
    ) {
      add(
        node.moduleReference.expression.text,
        "require",
        node.isTypeOnly,
        node,
      );
    } else if (ts.isCallExpression(node)) {
      const arg = node.arguments[0];
      if (arg !== undefined && ts.isStringLiteralLike(arg)) {
        if (node.expression.kind === ts.SyntaxKind.ImportKeyword) {
          add(arg.text, "dynamic", false, node);
        } else if (
          ts.isIdentifier(node.expression) &&
          node.expression.text === "require"
        ) {
          add(arg.text, "require", false, node);
        }
      }
    } else if (ts.isImportTypeNode(node)) {
      // typeof import("x") and import("x").Foo in type positions
      const arg = node.argument;
      if (ts.isLiteralTypeNode(arg) && ts.isStringLiteral(arg.literal)) {
        add(arg.literal.text, "dynamic", true, node);
      }
    }
    ts.forEachChild(node, visit);
  };

  visit(sf);
  return refs;
}

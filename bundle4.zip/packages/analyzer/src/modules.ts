// packages/analyzer/src/modules.ts
// Maps files to the Constitution's modules and lifts file edges to module
// edges. Pure. A module is { id, path } where path is a glob or a directory.
import type { Edge, FileGraph } from "./graph";
import { normalizePath } from "./graph";

export interface ModuleDef {
  id: string;
  path: string | string[];
}

export interface ModuleEdge {
  fromModule: string;
  toModule: string;
  fromFile: string;
  toFile: string;
  specifier: string;
  line: number;
  kind: Edge["kind"];
  typeOnly: boolean;
}

export interface ModuleAnalysis {
  /** Every file seen in the graph and the module it belongs to (null = none). */
  fileModules: Record<string, string | null>;
  /** Edges between two different modules. Edges inside one module are dropped. */
  edges: ModuleEdge[];
  /** Parsed code files that belong to no module, sorted. */
  unassigned: string[];
}

function normalizeGlob(glob: string): string {
  let g = glob.replace(/\\/g, "/").replace(/^\.\//, "").replace(/\/+$/, "");
  // "src/ui" means the directory src/ui and everything below it
  if (!/[*?]/.test(g)) g = `${g}/**`;
  return g;
}

const regexCache = new Map<string, RegExp>();

export function globToRegExp(glob: string): RegExp {
  const g = normalizeGlob(glob);
  const cached = regexCache.get(g);
  if (cached) return cached;

  let out = "";
  let i = 0;
  while (i < g.length) {
    if (g.startsWith("**/", i)) {
      out += "(?:.*/)?";
      i += 3;
    } else if (g.startsWith("/**", i) && i + 3 === g.length) {
      out += "(?:/.*)?";
      i += 3;
    } else if (g.startsWith("**", i)) {
      out += ".*";
      i += 2;
    } else if (g[i] === "*") {
      out += "[^/]*";
      i += 1;
    } else if (g[i] === "?") {
      out += "[^/]";
      i += 1;
    } else {
      out += g[i]!.replace(/[.+^${}()|[\]\\]/g, "\\$&");
      i += 1;
    }
  }
  const re = new RegExp(`^${out}$`);
  regexCache.set(g, re);
  return re;
}

export function matchesGlob(path: string, glob: string): boolean {
  return globToRegExp(glob).test(normalizePath(path));
}

// More literal characters = more specific glob.
function specificity(glob: string): number {
  return normalizeGlob(glob).replace(/[*?]/g, "").length;
}

/** The module a file belongs to. The most specific matching glob wins; ties go to the module declared first. */
export function moduleOf(path: string, modules: ReadonlyArray<ModuleDef>): string | null {
  let best: { id: string; score: number } | null = null;
  for (const m of modules) {
    const globs = Array.isArray(m.path) ? m.path : [m.path];
    for (const glob of globs) {
      if (!matchesGlob(path, glob)) continue;
      const score = specificity(glob);
      if (best === null || score > best.score) best = { id: m.id, score };
    }
  }
  return best ? best.id : null;
}

export function buildModuleEdges(
  graph: FileGraph,
  modules: ReadonlyArray<ModuleDef>,
): ModuleAnalysis {
  const fileModules: Record<string, string | null> = {};
  const assign = (p: string) => {
    if (!(p in fileModules)) fileModules[p] = moduleOf(p, modules);
    return fileModules[p] as string | null;
  };

  for (const f of graph.files) assign(f);

  const edges: ModuleEdge[] = [];
  for (const e of graph.edges) {
    const fromModule = assign(e.from);
    const toModule = assign(e.to);
    if (fromModule === null || toModule === null) continue;
    if (fromModule === toModule) continue;
    edges.push({
      fromModule,
      toModule,
      fromFile: e.from,
      toFile: e.to,
      specifier: e.specifier,
      line: e.line,
      kind: e.kind,
      typeOnly: e.typeOnly,
    });
  }

  const unassigned = graph.files.filter((f) => fileModules[f] === null).sort();
  return { fileModules, edges, unassigned };
}

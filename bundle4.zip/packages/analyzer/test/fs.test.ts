import { describe, it, expect } from "vitest";
import { mkdtempSync, mkdirSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { analyzeProject, loadTsconfigOptions, loadWorkspacePackages, readProjectFiles } from "../src/fs";

function fixture(): string {
  const root = mkdtempSync(join(tmpdir(), "arch-analyzer-"));
  const w = (p: string, c: string) => {
    mkdirSync(join(root, p, ".."), { recursive: true });
    writeFileSync(join(root, p), c);
  };
  w("tsconfig.json", `{ // comment\n "compilerOptions": { "baseUrl": ".", "paths": { "@/*": ["src/*"] } } }`);
  w("src/app.ts", `import { x } from "@/lib/x";\nimport { y } from "src/lib/y";`);
  w("src/lib/x.ts", `export const x = 1;`);
  w("src/lib/y.ts", `export const y = 1;`);
  w("packages/lib/package.json", `{ "name": "@demo/lib", "main": "./src/index.ts" }`);
  w("packages/lib/src/index.ts", `export const z = 1;`);
  w("packages/app/package.json", `{ "name": "@demo/app" }`);
  w("packages/app/index.ts", `import { z } from "@demo/lib";`);
  w("node_modules/pkg/index.js", `import "./nothing";`);
  w("dist/out.js", `x`);
  return root;
}

describe("fs layer", () => {
  const root = fixture();
  it("skips ignored directories", () => {
    const paths = readProjectFiles(root).map((f) => f.path);
    expect(paths.includes("node_modules/pkg/index.js")).toBe(false);
    expect(paths.includes("dist/out.js")).toBe(false);
    expect(paths.includes("src/app.ts")).toBe(true);
  });
  it("reads tsconfig paths and baseUrl", () => {
    const o = loadTsconfigOptions(root);
    expect(o.baseUrl).toBe("");
    expect(o.aliases).toEqual([{ prefix: "@/", targets: ["src/"] }]);
  });
  it("finds workspace packages and their entry files", () => {
    const pkgs = loadWorkspacePackages(root, readProjectFiles(root).map((f) => f.path));
    expect(pkgs).toEqual([
      { name: "@demo/app", dir: "packages/app", entry: "packages/app/index" },
      { name: "@demo/lib", dir: "packages/lib", entry: "packages/lib/src/index.ts" },
    ]);
  });
  it("turns imports of workspace packages into file edges", () => {
    const a = analyzeProject(root);
    const e = a.graph.edges.find((x) => x.from === "packages/app/index.ts");
    expect(e!.to).toBe("packages/lib/src/index.ts");
    expect(a.graph.externals.some((x) => x.name === "@demo/lib")).toBe(false);
  });
  it("analyzes a whole project", () => {
    const a = analyzeProject(root, [
      { id: "app", path: "src/app.ts" },
      { id: "lib", path: "src/lib" },
    ]);
    expect(a.graph.unresolved.length).toBe(0);
    expect(a.modules!.edges.filter((e) => e.fromModule === "app").length).toBe(2);
  });
});

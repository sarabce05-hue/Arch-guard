import { describe, it, expect } from "vitest";
import { buildFileGraph } from "../src/graph";
import { buildModuleEdges, matchesGlob, moduleOf } from "../src/modules";

const project = [
  { path: "src/ui/page.tsx", content: `import { q } from "../db/query";\nimport React from "react";\nimport "./missing";\nimport type { T } from "../db/types";` },
  { path: "src/db/query.ts", content: `import { t } from "./types";\nexport const q = 1;` },
  { path: "src/db/types.ts", content: `export type T = 1; export const t = 1;` },
  { path: "scripts/tool.ts", content: `import { q } from "../src/db/query";` },
  { path: "README.json", content: "" },
];

describe("buildFileGraph", () => {
  const g = buildFileGraph(project);
  it("lists code files only, sorted", () => {
    expect(g.files).toEqual(["scripts/tool.ts", "src/db/query.ts", "src/db/types.ts", "src/ui/page.tsx"]);
  });
  it("builds edges", () => {
    expect(g.edges.length).toBe(4);
    expect(g.edges.some((e) => e.from === "src/ui/page.tsx" && e.to === "src/db/query.ts" && e.line === 1)).toBe(true);
    const t = g.edges.find((e) => e.to === "src/db/types.ts" && e.from === "src/ui/page.tsx");
    expect(t!.typeOnly).toBe(true);
  });
  it("records externals and unresolved", () => {
    expect(g.externals.map((e) => e.name)).toEqual(["react"]);
    expect(g.unresolved.map((u) => u.specifier)).toEqual(["./missing"]);
  });
  it("is deterministic regardless of input order", () => {
    const g2 = buildFileGraph([...project].reverse());
    expect(g2).toEqual(g);
  });
});

describe("globs", () => {
  it("matches directories and wildcards", () => {
    expect(matchesGlob("src/ui/a/b.ts", "src/ui")).toBe(true);
    expect(matchesGlob("src/ui/a/b.ts", "src/ui/**")).toBe(true);
    expect(matchesGlob("src/uix/a.ts", "src/ui")).toBe(false);
    expect(matchesGlob("src/a.ts", "src/*.ts")).toBe(true);
    expect(matchesGlob("src/x/a.ts", "src/*.ts")).toBe(false);
    expect(matchesGlob("src/x/y/a.test.ts", "**/*.test.ts")).toBe(true);
    expect(matchesGlob("a.test.ts", "**/*.test.ts")).toBe(true);
  });
  it("most specific glob wins", () => {
    const mods = [
      { id: "ui", path: "src/**" },
      { id: "db", path: "src/db/**" },
    ];
    expect(moduleOf("src/db/query.ts", mods)).toBe("db");
    expect(moduleOf("src/ui/page.tsx", mods)).toBe("ui");
    expect(moduleOf("scripts/tool.ts", mods)).toBe(null);
  });
});

describe("buildModuleEdges", () => {
  const g = buildFileGraph(project);
  const mods = [
    { id: "ui", path: "src/ui" },
    { id: "db", path: ["src/db"] },
  ];
  const m = buildModuleEdges(g, mods);
  it("keeps only cross-module edges", () => {
    expect(m.edges.map((e) => `${e.fromModule}->${e.toModule}`)).toEqual(["ui->db", "ui->db"]);
  });
  it("lists unassigned files", () => {
    expect(m.unassigned).toEqual(["scripts/tool.ts"]);
    expect(m.fileModules["src/db/query.ts"]).toBe("db");
  });
});

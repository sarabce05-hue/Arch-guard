import { describe, it, expect } from "vitest";
import { extractImports } from "../src/imports";

describe("extractImports", () => {
  it("finds static imports, side-effect imports and export-from", () => {
    const src = `import a from "./a";
import { b } from "../b";
import "./side";
export * from "./c";
export { d } from "./d";
`;
    const r = extractImports("x.ts", src);
    expect(r.map((i) => i.specifier)).toEqual(["./a", "../b", "./side", "./c", "./d"]);
    expect(r.map((i) => i.line)).toEqual([1, 2, 3, 4, 5]);
    expect(r[3]!.kind).toBe("export-from");
  });

  it("marks type-only imports", () => {
    const src = `import type { A } from "./a";
import { type B, type C } from "./b";
import { type D, e } from "./c";
export type { F } from "./f";
`;
    const r = extractImports("x.ts", src);
    expect(r.map((i) => i.typeOnly)).toEqual([true, true, false, true]);
  });

  it("finds dynamic import and require", () => {
    const src = `const m = await import("./lazy");
const r = require("lodash");
const n = import(variable);
`;
    const r = extractImports("x.js", src);
    expect(r.map((i) => i.specifier)).toEqual(["./lazy", "lodash"]);
    expect(r[0]!.kind).toBe("dynamic");
    expect(r[1]!.kind).toBe("require");
  });

  it("finds import-type nodes as type-only", () => {
    const r = extractImports("x.ts", `let x: import("./t").T;`);
    expect(r.length).toBe(1);
    expect(r[0]!.typeOnly).toBe(true);
  });

  it("parses tsx", () => {
    const r = extractImports("x.tsx", `import React from "react";\nconst e = <div/>;`);
    expect(r.length).toBe(1);
  });

  it("ignores imports inside comments and strings", () => {
    const r = extractImports("x.ts", `// import a from "./a"\nconst s = 'import b from "./b"';`);
    expect(r.length).toBe(0);
  });
});

// packages/cli/src/emit.ts
// `arch emit`: write the instruction files that AI tools read.
// `--check` writes nothing and reports files that are out of date (for CI).
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { ALL_TARGETS, EmitError, emit, type EmitTarget } from "@arch/emitters";
import { loadConstitution, UsageError } from "./check";

export interface EmitResult {
  /** Files whose content changed (written, or would be written with --check). */
  changed: string[];
  unchanged: string[];
  checkOnly: boolean;
}

export function parseTargets(value: string | undefined): EmitTarget[] | undefined {
  if (value === undefined) return undefined;
  const names = value.split(",").map((s) => s.trim()).filter(Boolean);
  for (const n of names) {
    if (!(ALL_TARGETS as ReadonlyArray<string>).includes(n)) {
      throw new UsageError(`unknown target "${n}". Choose from: ${ALL_TARGETS.join(", ")}`);
    }
  }
  return names as EmitTarget[];
}

export function runEmit(
  root: string,
  options: { constitution?: string; targets?: EmitTarget[]; check?: boolean } = {},
): EmitResult {
  const absRoot = resolve(root);
  const constitution = loadConstitution(absRoot, options.constitution);

  const existing: Record<string, string> = {};
  for (const target of options.targets ?? ALL_TARGETS) {
    // read what is there now, so text the user wrote is kept
    const probe = emit(constitution, { targets: [target] })[0]!;
    const file = join(absRoot, probe.path);
    if (existsSync(file)) existing[probe.path] = readFileSync(file, "utf8");
  }

  let files;
  try {
    files = emit(constitution, { ...(options.targets ? { targets: options.targets } : {}), existing });
  } catch (e) {
    if (e instanceof EmitError) throw new UsageError(e.message);
    throw e;
  }

  const result: EmitResult = { changed: [], unchanged: [], checkOnly: options.check === true };
  for (const f of files) {
    if (existing[f.path] === f.content) {
      result.unchanged.push(f.path);
      continue;
    }
    result.changed.push(f.path);
    if (!options.check) {
      const file = join(absRoot, f.path);
      mkdirSync(dirname(file), { recursive: true });
      writeFileSync(file, f.content);
    }
  }
  return result;
}

export function formatEmit(r: EmitResult): string {
  const lines: string[] = [];
  const verb = r.checkOnly ? "out of date" : "written";
  for (const p of r.changed) lines.push(`${r.checkOnly ? "STALE" : "wrote"} ${p}`);
  for (const p of r.unchanged) lines.push(`ok    ${p}`);
  lines.push(
    r.changed.length === 0
      ? "All instruction files are up to date."
      : `${r.changed.length} file(s) ${verb}.${r.checkOnly ? " Run: arch emit" : ""}`,
  );
  return lines.join("\n");
}

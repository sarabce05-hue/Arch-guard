import { describe, it, expect } from "vitest";
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { parseArgs, run } from "../src/cli";
import { analyzeProject } from "@arch/analyzer";
import { loadConstitution, runCheck } from "../src/check";
import { runEmit } from "../src/emit";

function project(files: Record<string, string>): string {
  const root = mkdtempSync(join(tmpdir(), "arch-cli-"));
  for (const [p, c] of Object.entries(files)) {
    mkdirSync(join(root, p, ".."), { recursive: true });
    writeFileSync(join(root, p), c);
  }
  return root;
}

const CONSTITUTION = `
version: 1
modules:
  - { id: ui, path: "src/ui" }
  - { id: db, path: "src/db" }
rules:
  - { id: ui-no-db, type: deny, from: ui, to: db, message: "UI must not touch the database." }
`;

function capture() {
  const out: string[] = [];
  const err: string[] = [];
  return { io: { out: (t: string) => out.push(t), err: (t: string) => err.push(t) }, out, err };
}

describe("parseArgs", () => {
  it("reads command and options", () => {
    expect(parseArgs(["check", "--root", "x", "--format", "json"])).toEqual({
      command: "check", root: "x", constitution: undefined, format: "json", target: undefined, check: false,
    });
  });
});

describe("arch check", () => {
  const bad = project({
    ".arch/constitution.yaml": CONSTITUTION,
    "src/ui/page.ts": `import { q } from "../db/query";\nexport const p = q;`,
    "src/db/query.ts": `export const q = 1;`,
    "src/stray.ts": `export const s = 1;`,
  });
  const good = project({
    ".arch/constitution.yaml": CONSTITUTION,
    "src/ui/page.ts": `export const p = 1;`,
    "src/db/query.ts": `import { p } from "../ui/page";\nexport const q = p;`,
  });

  it("exits 1 and explains a violation", () => {
    const c = capture();
    expect(run(["check", "--root", bad], c.io)).toBe(1);
    const text = c.out.join("\n");
    expect(text).toContain("src/ui/page.ts:1");
    expect(text).toContain("ui-no-db");
    expect(text).toContain("UI must not touch the database.");
    expect(text).toContain("fix:");
    expect(text).toContain("src/stray.ts");
    expect(text).toContain("FAILED");
  });
  it("exits 0 when the rules hold", () => {
    const c = capture();
    expect(run(["check", "--root", good], c.io)).toBe(0);
    expect(c.out.join("\n")).toContain("OK");
  });
  it("prints JSON that tools can read", () => {
    const c = capture();
    run(["check", "--root", bad, "--format", "json"], c.io);
    const data = JSON.parse(c.out.join("\n"));
    expect(data.violations.length).toBe(1);
    expect(data.violations[0].ruleId).toBe("ui-no-db");
  });
  it("exits 2 when the Constitution is missing or invalid", () => {
    const empty = project({ "src/a.ts": "export {}" });
    const c1 = capture();
    expect(run(["check", "--root", empty], c1.io)).toBe(2);
    expect(c1.err.join("\n")).toContain("not found");

    const broken = project({ ".arch/constitution.yaml": "version: 2\nmodules: []" });
    const c2 = capture();
    expect(run(["check", "--root", broken], c2.io)).toBe(2);
    expect(c2.err.join("\n")).toContain("not a valid Constitution");
  });
  it("exits 2 for unknown commands and options", () => {
    expect(run(["frobnicate"], capture().io)).toBe(2);
    expect(run(["check", "--nope"], capture().io)).toBe(2);
    expect(run(["check", "--format", "xml"], capture().io)).toBe(2);
  });
  it("shows help", () => {
    const c = capture();
    expect(run(["--help"], c.io)).toBe(0);
    expect(c.out.join("\n")).toContain("Usage:");
  });
});

describe("dogfooding: this repository obeys its own Constitution", () => {
  // Tests run from packages/cli, so the repo root is two levels up.
  const root = join(process.cwd(), "../..");
  it("has no rule violations of severity error", () => {
    const result = runCheck(root);
    expect(result.report.violations.filter((v) => v.severity === "error")).toEqual([]);
  });
  it("sees the real dependencies between packages", () => {
    const { modules } = analyzeProject(root, loadConstitution(root).modules);
    const pairs = new Set(modules!.edges.map((e) => `${e.fromModule}->${e.toModule}`));
    expect(pairs.has("verifier->spec")).toBe(true);
    expect(pairs.has("cli->analyzer")).toBe(true);
    expect(pairs.has("cli->verifier")).toBe(true);
  });
});

describe("arch emit", () => {
  const files = {
    ".arch/constitution.yaml": CONSTITUTION,
    "src/ui/page.ts": "export const p = 1;",
    "CLAUDE.md": "# Mine\nBe kind.\n",
  };
  it("writes the instruction files and keeps the user's text", () => {
    const root = project(files);
    const c = capture();
    expect(run(["emit", "--root", root], c.io)).toBe(0);
    const claude = readFileSync(join(root, "CLAUDE.md"), "utf8");
    expect(claude).toContain("Be kind.");
    expect(claude).toContain("UI must not touch the database.");
    expect(readFileSync(join(root, "AGENTS.md"), "utf8")).toContain("# Architecture rules");
    expect(readFileSync(join(root, ".cursor/rules/arch-guard.mdc"), "utf8")).toContain("alwaysApply: true");
  });
  it("--check fails while files are stale and passes after emit", () => {
    const root = project(files);
    expect(run(["emit", "--check", "--root", root], capture().io)).toBe(1);
    expect(run(["emit", "--root", root], capture().io)).toBe(0);
    const c = capture();
    expect(run(["emit", "--check", "--root", root], c.io)).toBe(0);
    expect(c.out.join("\n")).toContain("up to date");
  });
  it("--check writes nothing", () => {
    const root = project(files);
    run(["emit", "--check", "--root", root], capture().io);
    let exists = true;
    try { readFileSync(join(root, "AGENTS.md")); } catch { exists = false; }
    expect(exists).toBe(false);
  });
  it("limits output with --target and rejects unknown targets", () => {
    const root = project(files);
    expect(run(["emit", "--root", root, "--target", "agents"], capture().io)).toBe(0);
    expect(readFileSync(join(root, "AGENTS.md"), "utf8")).toContain("Architecture rules");
    expect(run(["emit", "--root", root, "--target", "vim"], capture().io)).toBe(2);
  });
});

describe("dogfooding: generated instruction files are current", () => {
  it("AGENTS.md, CLAUDE.md, .cursor rules and replit.md match the Constitution", () => {
    const root = join(process.cwd(), "../..");
    expect(runEmit(root, { check: true }).changed).toEqual([]);
  });
});

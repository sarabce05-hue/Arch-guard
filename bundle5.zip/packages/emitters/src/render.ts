// packages/emitters/src/render.ts
// Turns a Constitution into instructions for an AI coding tool, as markdown.
// Pure and deterministic: the same Constitution always gives the same text.
import type { Constitution } from "@arch/spec";

type Rule = Constitution["rules"][number];

function describeRule(rule: Rule): string {
  const level = rule.severity === "warn" ? " (warning)" : "";
  if (rule.type === "deny") {
    const why = rule.message ? ` ${rule.message}` : "";
    return `\`${rule.from}\` must not import \`${rule.to}\`.${why}${level}`;
  }
  if (rule.type === "allow-only") {
    const list = rule.mayImport.length
      ? rule.mayImport.map((m) => `\`${m}\``).join(", ")
      : "no other module";
    return `\`${rule.module}\` may import only: ${list}.${level}`;
  }
  const what = rule.scope === "files" ? "files" : "modules";
  return `No import cycles between ${what}.${level}`;
}

function describeInvariant(c: Constitution, inv: Constitution["invariants"][number]): string {
  if (inv.check?.type === "rule-ref") {
    return `${inv.intent} (checked automatically by: ${inv.check.ruleIds.join(", ")})`;
  }
  if (inv.check?.type === "forbidden-pattern") {
    return `${inv.intent} (checked automatically: ${inv.check.message})`;
  }
  return `${inv.intent} (not checked automatically, so you are responsible for it)`;
}

export function renderBody(c: Constitution): string {
  const out: string[] = [];
  out.push("# Architecture rules");
  out.push("");
  out.push(
    "This project has an architecture Constitution in `.arch/constitution.yaml`. " +
      "These rules are enforced by `arch check`. Follow them in every change.",
  );

  out.push("", "## Modules", "");
  for (const m of c.modules) {
    const paths = (Array.isArray(m.path) ? m.path : [m.path]).map((p) => `\`${p}\``).join(", ");
    out.push(`- \`${m.id}\` (${paths})${m.description ? `: ${m.description}` : ""}`);
  }

  if (c.rules.length > 0) {
    out.push("", "## Dependency rules", "");
    for (const r of c.rules) out.push(`- ${describeRule(r)}`);
  }

  if (c.invariants.length > 0) {
    out.push("", "## Invariants", "");
    for (const i of c.invariants) out.push(`- ${describeInvariant(c, i)}`);
  }

  const decisions = c.decisions.filter((d) => d.status === "accepted");
  if (decisions.length > 0) {
    out.push("", "## Decisions already made", "");
    for (const d of decisions) out.push(`- ${d.title}. Why: ${d.why}`);
  }

  if (c.packs.length > 0) {
    out.push("", "## Engineering packs", "");
    out.push(`Enabled: ${c.packs.map((p) => `\`${p}\``).join(", ")}.`);
  }

  out.push("", "## How to work", "");
  out.push("1. Put new code inside the path of an existing module. Do not create code outside the module paths above.");
  out.push("2. Before adding an import from one module to another, check the dependency rules above.");
  out.push("3. When you finish a change, run `arch check`. Fix every error it reports.");
  out.push("4. Each violation comes with a `fix:` hint. Follow it instead of working around the rule.");
  out.push("5. Never edit `.arch/constitution.yaml` to make a violation disappear. If a rule seems wrong, stop and ask a human.");
  return out.join("\n");
}

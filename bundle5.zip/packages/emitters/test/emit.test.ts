import { describe, it, expect } from "vitest";
import { ConstitutionSchema } from "@arch/spec";
import { ALL_TARGETS, applyBlock, BEGIN, END, EmitError, emit } from "../src/emit";
import { renderBody } from "../src/render";

const c = ConstitutionSchema.parse({
  version: 1,
  modules: [
    { id: "ui", path: "src/ui", description: "Screens" },
    { id: "db", path: ["src/db", "src/models"] },
  ],
  rules: [
    { id: "ui-no-db", type: "deny", from: "ui", to: "db", message: "Go through the service layer." },
    { id: "db-deps", type: "allow-only", module: "db", mayImport: [] },
    { id: "ui-deps", type: "allow-only", module: "ui", mayImport: ["db"], severity: "warn" },
    { id: "no-cycles", type: "no-cycles" },
  ],
  invariants: [
    { id: "money", intent: "Money is always an integer in cents." },
    { id: "layers", intent: "UI never touches the database.", check: { type: "rule-ref", ruleIds: ["ui-no-db"] } },
  ],
  decisions: [
    { id: "d1", title: "Use Postgres", why: "Relational data" },
    { id: "d2", title: "Use Mongo", why: "old", status: "superseded" },
  ],
  packs: ["saas-baseline@1"],
});

describe("renderBody", () => {
  const text = renderBody(c);
  it("lists modules with paths and descriptions", () => {
    expect(text).toContain("`ui` (`src/ui`): Screens");
    expect(text).toContain("`db` (`src/db`, `src/models`)");
  });
  it("explains each kind of rule", () => {
    expect(text).toContain("`ui` must not import `db`. Go through the service layer.");
    expect(text).toContain("`db` may import only: no other module.");
    expect(text).toContain("`ui` may import only: `db`. (warning)");
    expect(text).toContain("No import cycles between modules.");
  });
  it("separates checked and unchecked invariants", () => {
    expect(text).toContain("Money is always an integer in cents. (not checked automatically");
    expect(text).toContain("(checked automatically by: ui-no-db)");
  });
  it("includes only accepted decisions and the packs", () => {
    expect(text).toContain("Use Postgres. Why: Relational data");
    expect(text.includes("Use Mongo")).toBe(false);
    expect(text).toContain("`saas-baseline@1`");
  });
  it("tells the AI to run arch check and not to edit the Constitution", () => {
    expect(text).toContain("`arch check`");
    expect(text).toContain("Never edit `.arch/constitution.yaml`");
  });
  it("is deterministic", () => {
    expect(renderBody(c)).toBe(text);
  });
});

describe("applyBlock", () => {
  it("creates a file when none exists", () => {
    const r = applyBlock(undefined, "BODY");
    expect(r).toBe(`${BEGIN}\nBODY\n${END}\n`);
  });
  it("keeps the user's own text and appends the block", () => {
    const r = applyBlock("# My notes\n\nUse tabs.\n", "BODY");
    expect(r.startsWith("# My notes\n\nUse tabs.\n\n")).toBe(true);
    expect(r).toContain("BODY");
  });
  it("replaces an old block and keeps text around it", () => {
    const first = applyBlock("# Top\n", "OLD");
    const withTail = first + "\n## Mine\nkeep me\n";
    const r = applyBlock(withTail, "NEW");
    expect(r.includes("OLD")).toBe(false);
    expect(r).toContain("NEW");
    expect(r).toContain("# Top");
    expect(r).toContain("keep me");
  });
  it("is idempotent", () => {
    const once = applyBlock("# Top\n", "BODY");
    expect(applyBlock(once, "BODY")).toBe(once);
  });
  it("refuses a block with a begin marker but no end marker", () => {
    let error: unknown;
    try { applyBlock(`${BEGIN}\nhalf`, "BODY"); } catch (e) { error = e; }
    expect(error instanceof EmitError).toBe(true);
  });
});

describe("emit", () => {
  it("produces one file per target with the right paths", () => {
    const files = emit(c);
    expect(files.map((f) => f.path)).toEqual([
      "AGENTS.md", "CLAUDE.md", ".cursor/rules/arch-guard.mdc", "replit.md",
    ]);
    expect(files.length).toBe(ALL_TARGETS.length);
  });
  it("writes a Cursor rule that is always applied", () => {
    const f = emit(c, { targets: ["cursor"] })[0]!;
    expect(f.content.startsWith("---\n")).toBe(true);
    expect(f.content).toContain("alwaysApply: true");
    expect(f.content).toContain("# Architecture rules");
  });
  it("respects the target filter and existing files", () => {
    const files = emit(c, { targets: ["claude"], existing: { "CLAUDE.md": "# Project\nBe nice.\n" } });
    expect(files.length).toBe(1);
    expect(files[0]!.content).toContain("Be nice.");
    expect(files[0]!.content).toContain("# Architecture rules");
  });
  it("is stable when run again on its own output", () => {
    const first = emit(c);
    const existing = Object.fromEntries(first.map((f) => [f.path, f.content]));
    expect(emit(c, { existing })).toEqual(first);
  });
});

<!-- arch-guard:begin (generated from .arch/constitution.yaml; do not edit between the markers) -->
# Architecture rules

This project has an architecture Constitution in `.arch/constitution.yaml`. These rules are enforced by `arch check`. Follow them in every change.

## Modules

- `spec` (`packages/spec/**`): Constitution, pack and report schemas
- `analyzer` (`packages/analyzer/**`): Parses TS/JS and builds the module graph
- `verifier` (`packages/verifier/**`): Evaluates rules and produces a CheckReport
- `emitters` (`packages/emitters/**`): Renders instruction files for each AI tool
- `packs` (`packs/**`): First-party Engineering Packs (declarative data)
- `intent` (`packages/intent/**`): Closed. LLM turns natural language into proposed rules
- `cli` (`packages/cli/**`): The arch command line
- `mcp-server` (`packages/mcp-server/**`): Exposes constraints and checks to agents over MCP
- `github-app` (`apps/github-app/**`): Closed. PR checks and comments
- `api` (`apps/api/**`): Closed. Cloud API and persistence
- `web` (`apps/web/**`): Closed. Dashboard

## Dependency rules

- `spec` may import only: no other module.
- `analyzer` may import only: `spec`.
- `verifier` may import only: `spec`.
- `emitters` may import only: `spec`.
- `packs` may import only: `spec`.
- `intent` may import only: `spec`, `verifier`.
- `cli` may import only: `spec`, `analyzer`, `verifier`, `emitters`.
- `mcp-server` may import only: `spec`, `analyzer`, `verifier`.
- `github-app` may import only: `spec`, `analyzer`, `verifier`.
- `api` may import only: `spec`.
- `web` may import only: `spec`.
- No import cycles between modules.

## Invariants

- Open-source packages must never import closed packages. (checked automatically by: spec-imports-nothing, analyzer-deps, verifier-deps, emitters-deps, packs-deps, cli-deps, mcp-server-deps)
- verifier and analyzer never import network, filesystem-write, database or LLM modules. (not checked automatically, so you are responsible for it)
- Only the intent package may call an LLM provider. (not checked automatically, so you are responsible for it)
- Only the api app may access the database, through repository functions. (not checked automatically, so you are responsible for it)
- cli, mcp-server and github-app contain no rule logic; they call verifier. (not checked automatically, so you are responsible for it)
- Engineering Packs are declarative data only and never contain executable code. (not checked automatically, so you are responsible for it)

## Decisions already made

- Constitution is YAML, schema in Zod. Why: Readable by humans, validated by code.
- Verifier is deterministic and uses no LLM. Why: Trust and reproducibility.
- Git/PR check is the universal integration. Why: Works with every tool without permission.
- Open core. Why: Standard adoption; monetize cloud and intent.
- TypeScript and JavaScript only in V1. Why: Matches most AI-built projects and limits scope.
- Source never leaves the user's environment. Why: Adoption and security.
- Packs are declarative data, never code. Why: Safe community contributions, reviewable, deterministic.
- Packs start narrow, one stack and 15 to 20 rules. Why: False positives are the main product risk.

## How to work

1. Put new code inside the path of an existing module. Do not create code outside the module paths above.
2. Before adding an import from one module to another, check the dependency rules above.
3. When you finish a change, run `arch check`. Fix every error it reports.
4. Each violation comes with a `fix:` hint. Follow it instead of working around the rule.
5. Never edit `.arch/constitution.yaml` to make a violation disappear. If a rule seems wrong, stop and ask a human.
<!-- arch-guard:end -->

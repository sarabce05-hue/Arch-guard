// packages/analyzer/src/fs.ts
// The only place the analyzer touches the disk, and it only READS.
import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import { join, posix } from "node:path";
import ts from "typescript";
import { buildFileGraph, CODE_FILE, type FileGraph, type SourceFile } from "./graph";
import { buildModuleEdges, type ModuleAnalysis, type ModuleDef } from "./modules";
import type { Alias, ResolveOptions } from "./resolve";

export const DEFAULT_IGNORED_DIRS = [
  "node_modules",
  ".git",
  "dist",
  "build",
  "out",
  ".next",
  ".turbo",
  "coverage",
];

export interface ReadOptions {
  ignoredDirs?: string[];
  /** Files larger than this are listed but not parsed. */
  maxFileBytes?: number;
}

/** Reads every code file (and .json files, which can be import targets) under root. */
export function readProjectFiles(
  root: string,
  options: ReadOptions = {},
): SourceFile[] {
  const ignored = new Set(options.ignoredDirs ?? DEFAULT_IGNORED_DIRS);
  const maxBytes = options.maxFileBytes ?? 1_000_000;
  const out: SourceFile[] = [];

  const walk = (dir: string, rel: string) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      if (entry.isSymbolicLink()) continue; // avoid loops
      const relPath = rel ? `${rel}/${entry.name}` : entry.name;
      const abs = join(dir, entry.name);
      if (entry.isDirectory()) {
        if (!ignored.has(entry.name)) walk(abs, relPath);
      } else if (entry.isFile()) {
        if (CODE_FILE.test(entry.name)) {
          const tooBig = statSync(abs).size > maxBytes;
          out.push({ path: relPath, content: tooBig ? "" : readFileSync(abs, "utf8") });
        } else if (entry.name.endsWith(".json")) {
          out.push({ path: relPath, content: "" });
        }
      }
    }
  };

  walk(root, "");
  return out.sort((a, b) => a.path.localeCompare(b.path));
}

function dirPrefix(p: string): string {
  const n = posix.normalize(p.replace(/\\/g, "/"));
  if (n === "." || n === "./") return "";
  return n.endsWith("/") ? n : `${n}/`;
}

/**
 * Reads tsconfig.json "paths" and "baseUrl" (comments allowed).
 * Limitation: does not follow "extends".
 */
export function loadTsconfigOptions(root: string): ResolveOptions {
  const file = join(root, "tsconfig.json");
  if (!existsSync(file)) return {};

  const parsed = ts.parseConfigFileTextToJson(file, readFileSync(file, "utf8"));
  const compilerOptions = parsed.config?.compilerOptions ?? {};
  const baseUrl: string | undefined =
    typeof compilerOptions.baseUrl === "string"
      ? dirPrefix(compilerOptions.baseUrl)
      : undefined;

  const aliases: Alias[] = [];
  const paths = compilerOptions.paths;
  if (paths && typeof paths === "object") {
    for (const [key, value] of Object.entries(paths)) {
      if (!key.endsWith("/*") || !Array.isArray(value)) continue;
      const targets = value
        .filter((t): t is string => typeof t === "string" && t.endsWith("*"))
        .map((t) => dirPrefix(posix.join(baseUrl ?? "", t.slice(0, -1))));
      if (targets.length > 0) aliases.push({ prefix: key.slice(0, -1), targets });
    }
  }

  const options: ResolveOptions = { aliases };
  if (baseUrl !== undefined) options.baseUrl = baseUrl;
  return options;
}

export interface ProjectAnalysis {
  graph: FileGraph;
  /** Present when modules were given. */
  modules?: ModuleAnalysis;
}

/** One call: read the project, load tsconfig, build the graph, map to modules. */
export function analyzeProject(
  root: string,
  modules?: ReadonlyArray<ModuleDef>,
  readOptions?: ReadOptions,
): ProjectAnalysis {
  const files = readProjectFiles(root, readOptions);
  const graph = buildFileGraph(files, loadTsconfigOptions(root));
  return modules ? { graph, modules: buildModuleEdges(graph, modules) } : { graph };
}

// packages/analyzer/src/resolve.ts
// Turns an import specifier into a project file, an external package or
// "unresolved". Pure: works on a set of known file paths, never touches disk.
import { posix } from "node:path";

/** `@/` -> `src/` means: import "@/x" is the file "src/x". Targets end with "/" or are "". */
export interface Alias {
  prefix: string;
  targets: string[];
}

export interface ResolveOptions {
  aliases?: Alias[];
  /** tsconfig baseUrl as a directory prefix ("" for the root, "src/" for src). */
  baseUrl?: string;
}

export type Resolution =
  | { kind: "file"; path: string }
  | { kind: "external"; name: string }
  | { kind: "unresolved" };

const EXTENSIONS = [
  ".ts",
  ".tsx",
  ".js",
  ".jsx",
  ".mjs",
  ".cjs",
  ".mts",
  ".cts",
  ".json",
];

// ESM-style TypeScript writes "./a.js" for the file "a.ts".
const JS_TO_TS: Record<string, string[]> = {
  ".js": [".ts", ".tsx"],
  ".jsx": [".tsx"],
  ".mjs": [".mts"],
  ".cjs": [".cts"],
};

function resolveCandidate(
  base: string,
  files: ReadonlySet<string>,
): string | null {
  if (files.has(base)) return base;

  const ext = posix.extname(base);
  const swaps = JS_TO_TS[ext];
  if (swaps) {
    const stem = base.slice(0, -ext.length);
    for (const e of swaps) if (files.has(stem + e)) return stem + e;
  }

  for (const e of EXTENSIONS) if (files.has(base + e)) return base + e;
  for (const e of EXTENSIONS) {
    const index = `${base}/index${e}`;
    if (files.has(index)) return index;
  }
  return null;
}

function packageName(specifier: string): string {
  const parts = specifier.split("/");
  if (specifier.startsWith("@") && parts.length >= 2) {
    return `${parts[0]}/${parts[1]}`;
  }
  return parts[0] ?? specifier;
}

export function resolveImport(
  fromFile: string,
  specifier: string,
  files: ReadonlySet<string>,
  options: ResolveOptions = {},
): Resolution {
  // Relative: ./x  ../x  .  ..
  if (
    specifier === "." ||
    specifier === ".." ||
    specifier.startsWith("./") ||
    specifier.startsWith("../")
  ) {
    const base = posix.normalize(
      posix.join(posix.dirname(fromFile), specifier),
    );
    const found = resolveCandidate(base, files);
    return found ? { kind: "file", path: found } : { kind: "unresolved" };
  }

  if (specifier.startsWith("node:")) {
    return { kind: "external", name: specifier };
  }

  // Aliases from tsconfig "paths", e.g. "@/*" -> "src/*"
  for (const alias of options.aliases ?? []) {
    if (specifier.startsWith(alias.prefix)) {
      const rest = specifier.slice(alias.prefix.length);
      for (const target of alias.targets) {
        const found = resolveCandidate(
          posix.normalize(target + rest),
          files,
        );
        if (found) return { kind: "file", path: found };
      }
      return { kind: "unresolved" };
    }
  }

  // tsconfig baseUrl: bare imports can point inside the project
  if (options.baseUrl !== undefined) {
    const found = resolveCandidate(
      posix.normalize(options.baseUrl + specifier),
      files,
    );
    if (found) return { kind: "file", path: found };
  }

  return { kind: "external", name: packageName(specifier) };
}

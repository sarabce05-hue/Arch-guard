import { describe, it, expect } from "vitest";
import { mkdtempSync, mkdirSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { analyzeProject, loadTsconfigOptions, readProjectFiles } from "../src/fs";

function fixture(): string {
  const root = mkdtempSync(join(tmpdir(), "arch-analyzer-"));
  const w = (p: string, c: string) => {
    mkdirSync(join(root, p, ".."), { recursive: true });
    writeFileSync(join(root, p), c);
  };
  w("tsconfig.json", `{ // comment\n "compilerOptions": { "baseUrl": ".", "paths": { "@/*": ["src/*"] } } }`);
  w("src/app.ts", `import { x } from "@/lib/x";\nimport { y } from "src/lib/y";`);
  w("src/lib/x.ts", `export const x = 1;`);
  w("src/lib/y.ts", `export const y = 1;`);
  w("node_modules/pkg/index.js", `import "./nothing";`);
  w("dist/out.js", `x`);
  return root;
}

describe("fs layer", () => {
  const root = fixture();
  it("skips ignored directories", () => {
    const paths = readProjectFiles(root).map((f) => f.path);
    expect(paths).toEqual(["src/app.ts", "src/lib/x.ts", "src/lib/y.ts", "tsconfig.json"]);
  });
  it("reads tsconfig paths and baseUrl", () => {
    const o = loadTsconfigOptions(root);
    expect(o.baseUrl).toBe("");
    expect(o.aliases).toEqual([{ prefix: "@/", targets: ["src/"] }]);
  });
  it("analyzes a whole project", () => {
    const a = analyzeProject(root, [
      { id: "app", path: "src/app.ts" },
      { id: "lib", path: "src/lib" },
    ]);
    expect(a.graph.edges.length).toBe(2);
    expect(a.graph.unresolved.length).toBe(0);
    expect(a.modules!.edges.length).toBe(2);
  });
});

import { describe, it, expect } from "vitest";
import { resolveImport } from "../src/resolve";

const files = new Set([
  "src/a.ts",
  "src/b/index.ts",
  "src/c.tsx",
  "src/data.json",
  "src/ui/button.tsx",
  "lib/util.ts",
]);

describe("resolveImport", () => {
  it("resolves relative files with extension guessing", () => {
    expect(resolveImport("src/x.ts", "./a", files)).toEqual({ kind: "file", path: "src/a.ts" });
    expect(resolveImport("src/x.ts", "./c", files)).toEqual({ kind: "file", path: "src/c.tsx" });
    expect(resolveImport("src/x.ts", "./data.json", files)).toEqual({ kind: "file", path: "src/data.json" });
  });
  it("resolves directory index", () => {
    expect(resolveImport("src/x.ts", "./b", files)).toEqual({ kind: "file", path: "src/b/index.ts" });
  });
  it("maps .js to .ts", () => {
    expect(resolveImport("src/x.ts", "./a.js", files)).toEqual({ kind: "file", path: "src/a.ts" });
  });
  it("resolves parent paths", () => {
    expect(resolveImport("src/ui/z.ts", "../a", files)).toEqual({ kind: "file", path: "src/a.ts" });
  });
  it("reports missing relative files as unresolved", () => {
    expect(resolveImport("src/x.ts", "./nope", files)).toEqual({ kind: "unresolved" });
  });
  it("detects external packages", () => {
    expect(resolveImport("src/x.ts", "react", files)).toEqual({ kind: "external", name: "react" });
    expect(resolveImport("src/x.ts", "lodash/get", files)).toEqual({ kind: "external", name: "lodash" });
    expect(resolveImport("src/x.ts", "@supabase/supabase-js", files)).toEqual({ kind: "external", name: "@supabase/supabase-js" });
    expect(resolveImport("src/x.ts", "node:fs", files)).toEqual({ kind: "external", name: "node:fs" });
  });
  it("uses aliases", () => {
    const o = { aliases: [{ prefix: "@/", targets: ["src/"] }] };
    expect(resolveImport("lib/util.ts", "@/ui/button", files, o)).toEqual({ kind: "file", path: "src/ui/button.tsx" });
    expect(resolveImport("lib/util.ts", "@/missing", files, o)).toEqual({ kind: "unresolved" });
  });
  it("uses baseUrl", () => {
    expect(resolveImport("src/x.ts", "ui/button", files, { baseUrl: "src/" })).toEqual({ kind: "file", path: "src/ui/button.tsx" });
    expect(resolveImport("src/x.ts", "react", files, { baseUrl: "src/" })).toEqual({ kind: "external", name: "react" });
  });
});

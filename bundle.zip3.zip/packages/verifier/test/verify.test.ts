import { describe, it, expect } from "vitest";
import { ConstitutionSchema, CheckReportSchema } from "@arch/spec";
import { hasErrors, verify, type FileEdgeInput } from "../src/verify";

const edge = (from: string, to: string, line = 1, typeOnly = false): FileEdgeInput => ({
  from, to, specifier: "./" + to.split("/").pop(), line, typeOnly,
});

function run(rules: unknown[], edges: FileEdgeInput[], extra: Record<string, unknown> = {}) {
  const constitution = ConstitutionSchema.parse({
    version: 1,
    modules: [
      { id: "ui", path: "src/ui" },
      { id: "db", path: "src/db" },
      { id: "core", path: "src/core" },
    ],
    rules,
    ...extra,
  });
  const files = ["src/ui/a.ts", "src/db/b.ts", "src/core/c.ts", "src/db/b2.ts"];
  const fileModules: Record<string, string | null> = {
    "src/ui/a.ts": "ui", "src/db/b.ts": "db", "src/core/c.ts": "core", "src/db/b2.ts": "db",
  };
  return verify({ constitution, files, edges, fileModules }, { durationMs: 0 });
}

describe("deny", () => {
  const rule = { type: "deny", id: "ui-no-db", from: "ui", to: "db", message: "UI must go through core." };
  it("flags a forbidden import with file, line and fixHint", () => {
    const r = run([rule], [edge("src/ui/a.ts", "src/db/b.ts", 7)]);
    expect(r.violations.length).toBe(1);
    const v = r.violations[0]!;
    expect(v.ruleId).toBe("ui-no-db");
    expect(v.file).toBe("src/ui/a.ts");
    expect(v.line).toBe(7);
    expect(v.severity).toBe("error");
    expect(v.message).toBe("UI must go through core.");
    expect(v.fixHint).toContain("src/ui/a.ts");
  });
  it("ignores imports that are allowed or inside one module", () => {
    const r = run([rule], [edge("src/ui/a.ts", "src/core/c.ts"), edge("src/db/b.ts", "src/db/b2.ts")]);
    expect(r.violations).toEqual([]);
  });
  it("respects warn severity", () => {
    const r = run([{ ...rule, severity: "warn" }], [edge("src/ui/a.ts", "src/db/b.ts")]);
    expect(r.violations[0]!.severity).toBe("warn");
    expect(hasErrors(r)).toBe(false);
  });
});

describe("allow-only", () => {
  const rule = { type: "allow-only", id: "ui-deps", module: "ui", mayImport: ["core"] };
  it("flags imports outside the allow list", () => {
    const r = run([rule], [edge("src/ui/a.ts", "src/db/b.ts", 3), edge("src/ui/a.ts", "src/core/c.ts", 4)]);
    expect(r.violations.length).toBe(1);
    expect(r.violations[0]!.to).toBe("db");
    expect(r.violations[0]!.line).toBe(3);
    expect(hasErrors(r)).toBe(true);
  });
  it("does not constrain other modules", () => {
    const r = run([rule], [edge("src/db/b.ts", "src/ui/a.ts")]);
    expect(r.violations).toEqual([]);
  });
});

describe("no-cycles", () => {
  it("finds a module cycle", () => {
    const r = run(
      [{ type: "no-cycles", id: "no-cycles" }],
      [edge("src/ui/a.ts", "src/db/b.ts", 1), edge("src/db/b.ts", "src/ui/a.ts", 2)],
    );
    expect(r.violations.length).toBe(1);
    expect(r.violations[0]!.message).toContain("db <-> ui");
  });
  it("ignores type-only edges when looking for cycles", () => {
    const r = run(
      [{ type: "no-cycles", id: "no-cycles" }],
      [edge("src/ui/a.ts", "src/db/b.ts", 1), edge("src/db/b.ts", "src/ui/a.ts", 2, true)],
    );
    expect(r.violations).toEqual([]);
  });
  it("finds a file cycle inside one module", () => {
    const r = run(
      [{ type: "no-cycles", id: "no-file-cycles", scope: "files" }],
      [edge("src/db/b.ts", "src/db/b2.ts", 1), edge("src/db/b2.ts", "src/db/b.ts", 5)],
    );
    expect(r.violations.length).toBe(1);
    expect(r.violations[0]!.file).toBe("src/db/b.ts");
    expect(r.violations[0]!.from).toBe("db");
  });
});

describe("report", () => {
  it("is valid against the spec schema and sorted", () => {
    const r = run(
      [{ type: "deny", id: "ui-no-db", from: "ui", to: "db" }],
      [edge("src/ui/a.ts", "src/db/b.ts", 9), edge("src/ui/a.ts", "src/db/b.ts", 2)],
    );
    expect(CheckReportSchema.safeParse(r).success).toBe(true);
    expect(r.violations.map((v) => v.line)).toEqual([2, 9]);
    expect(r.analyzedFiles).toBe(4);
  });
  it("lists invariants without an executable check as unverified", () => {
    const r = run(
      [{ type: "deny", id: "ui-no-db", from: "ui", to: "db" }],
      [],
      {
        invariants: [
          { id: "money-in-cents", intent: "All money values are integers in cents." },
          { id: "layering", intent: "UI never touches the database.", check: { type: "rule-ref", ruleIds: ["ui-no-db"] } },
          { id: "no-secrets", intent: "No secret keys in source files.", check: { type: "forbidden-pattern", paths: ["src"], pattern: "sk_live", message: "secret" } },
        ],
      },
    );
    expect(r.unverifiedInvariants).toEqual(["money-in-cents", "no-secrets"]);
  });
  it("is deterministic", () => {
    const edges = [edge("src/ui/a.ts", "src/db/b.ts", 9), edge("src/ui/a.ts", "src/core/c.ts", 2)];
    const rules = [{ type: "allow-only", id: "ui-deps", module: "ui", mayImport: [] }];
    expect(run(rules, edges)).toEqual(run(rules, [...edges].reverse()));
  });
});

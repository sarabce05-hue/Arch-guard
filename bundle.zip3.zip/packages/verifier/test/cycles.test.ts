import { describe, it, expect } from "vitest";
import { findCycles } from "../src/cycles";

const e = (from: string, to: string) => ({ from, to });

describe("findCycles", () => {
  it("returns nothing for a DAG", () => {
    expect(findCycles(["a", "b", "c"], [e("a", "b"), e("b", "c"), e("a", "c")])).toEqual([]);
  });
  it("finds a two-node cycle", () => {
    expect(findCycles(["a", "b"], [e("a", "b"), e("b", "a")])).toEqual([["a", "b"]]);
  });
  it("finds a three-node cycle and ignores the rest", () => {
    expect(
      findCycles(["a", "b", "c", "d"], [e("a", "b"), e("b", "c"), e("c", "a"), e("c", "d")]),
    ).toEqual([["a", "b", "c"]]);
  });
  it("finds two separate cycles, sorted", () => {
    expect(
      findCycles(["a", "b", "x", "y"], [e("y", "x"), e("x", "y"), e("b", "a"), e("a", "b")]),
    ).toEqual([["a", "b"], ["x", "y"]]);
  });
  it("reports self-loops", () => {
    expect(findCycles(["a"], [e("a", "a")])).toEqual([["a"]]);
  });
  it("ignores edges to unknown nodes", () => {
    expect(findCycles(["a"], [e("a", "zzz")])).toEqual([]);
  });
  it("survives a very long chain without stack overflow", () => {
    const nodes = Array.from({ length: 50000 }, (_, i) => `n${i}`);
    const edges = nodes.slice(1).map((n, i) => e(nodes[i]!, n));
    edges.push(e(nodes[nodes.length - 1]!, nodes[0]!));
    const r = findCycles(nodes, edges);
    expect(r.length).toBe(1);
    expect(r[0]!.length).toBe(50000);
  });
});

// packages/verifier/src/cycles.ts
// Finds groups of nodes that depend on each other (strongly connected
// components, Tarjan's algorithm). Iterative, so huge graphs cannot overflow
// the call stack. Deterministic: nodes and results are sorted.

/** Returns every group of 2+ nodes that form a cycle, plus self-loops as 1-node groups. */
export function findCycles(
  nodes: ReadonlyArray<string>,
  edges: ReadonlyArray<{ from: string; to: string }>,
): string[][] {
  const ids = [...new Set(nodes)].sort();
  const adj = new Map<string, string[]>(ids.map((n) => [n, []]));
  const selfLoops = new Set<string>();
  for (const e of edges) {
    if (!adj.has(e.from) || !adj.has(e.to)) continue;
    if (e.from === e.to) selfLoops.add(e.from);
    else adj.get(e.from)!.push(e.to);
  }
  for (const list of adj.values()) list.sort();

  const index = new Map<string, number>();
  const low = new Map<string, number>();
  const onStack = new Set<string>();
  const stack: string[] = [];
  const result: string[][] = [];
  let counter = 0;

  for (const root of ids) {
    if (index.has(root)) continue;
    const work: Array<{ node: string; next: number }> = [{ node: root, next: 0 }];
    index.set(root, counter);
    low.set(root, counter);
    counter++;
    stack.push(root);
    onStack.add(root);

    while (work.length > 0) {
      const frame = work[work.length - 1]!;
      const neighbours = adj.get(frame.node)!;
      if (frame.next < neighbours.length) {
        const w = neighbours[frame.next++]!;
        if (!index.has(w)) {
          index.set(w, counter);
          low.set(w, counter);
          counter++;
          stack.push(w);
          onStack.add(w);
          work.push({ node: w, next: 0 });
        } else if (onStack.has(w)) {
          low.set(frame.node, Math.min(low.get(frame.node)!, index.get(w)!));
        }
      } else {
        work.pop();
        const parent = work[work.length - 1];
        if (parent) {
          low.set(parent.node, Math.min(low.get(parent.node)!, low.get(frame.node)!));
        }
        if (low.get(frame.node) === index.get(frame.node)) {
          const group: string[] = [];
          let w: string;
          do {
            w = stack.pop()!;
            onStack.delete(w);
            group.push(w);
          } while (w !== frame.node);
          if (group.length > 1) result.push(group.sort());
        }
      }
    }
  }

  for (const n of [...selfLoops].sort()) result.push([n]);
  return result.sort((a, b) => a[0]!.localeCompare(b[0]!));
}

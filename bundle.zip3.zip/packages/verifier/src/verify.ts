// packages/verifier/src/verify.ts
// Evaluates the Constitution's rules against an analyzed project and returns
// a CheckReport. Pure and deterministic: no disk, no network, no LLM.
import type { CheckReport, Constitution, Violation } from "@arch/spec";
import { findCycles } from "./cycles";

/** The shape of the analyzer's output that the verifier needs. */
export interface FileEdgeInput {
  from: string;
  to: string;
  specifier: string;
  line: number;
  typeOnly: boolean;
}

export interface VerifyInput {
  constitution: Constitution;
  /** Parsed code files (analyzer: graph.files). */
  files: ReadonlyArray<string>;
  /** Import edges between project files (analyzer: graph.edges). */
  edges: ReadonlyArray<FileEdgeInput>;
  /** File -> module id, or null (analyzer: modules.fileModules). */
  fileModules: Readonly<Record<string, string | null>>;
}

export interface VerifyOptions {
  /** Override the measured duration (used by tests for stable output). */
  durationMs?: number;
}

type Rule = Constitution["rules"][number];

function bySeverityThenPlace(a: Violation, b: Violation): number {
  return (
    a.file.localeCompare(b.file) ||
    (a.line ?? 0) - (b.line ?? 0) ||
    a.ruleId.localeCompare(b.ruleId)
  );
}

function checkDeny(
  rule: Extract<Rule, { type: "deny" }>,
  edges: ReadonlyArray<ModuleEdge>,
): Violation[] {
  return edges
    .filter((e) => e.fromModule === rule.from && e.toModule === rule.to)
    .map((e) => ({
      ruleId: rule.id,
      severity: rule.severity,
      message:
        rule.message ??
        `Module "${rule.from}" must not import module "${rule.to}".`,
      file: e.from,
      line: e.line,
      from: rule.from,
      to: rule.to,
      fixHint:
        `Remove the import of "${e.specifier}" from ${e.from} (line ${e.line}). ` +
        `Code in "${rule.from}" must not depend on "${rule.to}". ` +
        `Move the shared logic into a module both may use, or pass the needed value in as a parameter.`,
    }));
}

function checkAllowOnly(
  rule: Extract<Rule, { type: "allow-only" }>,
  edges: ReadonlyArray<ModuleEdge>,
): Violation[] {
  const allowed = new Set(rule.mayImport);
  return edges
    .filter((e) => e.fromModule === rule.module && !allowed.has(e.toModule))
    .map((e) => ({
      ruleId: rule.id,
      severity: rule.severity,
      message: `Module "${rule.module}" may only import [${[...allowed].sort().join(", ") || "nothing"}], but imports "${e.toModule}".`,
      file: e.from,
      line: e.line,
      from: rule.module,
      to: e.toModule,
      fixHint:
        `Remove the import of "${e.specifier}" from ${e.from} (line ${e.line}). ` +
        `"${rule.module}" is only allowed to depend on: ${[...allowed].sort().join(", ") || "nothing"}. ` +
        `Move the needed code into an allowed module, or ask a human to change the rule ${rule.id} in .arch/constitution.yaml.`,
    }));
}

interface ModuleEdge extends FileEdgeInput {
  fromModule: string;
  toModule: string;
}

function checkCycles(
  rule: Extract<Rule, { type: "no-cycles" }>,
  input: VerifyInput,
  moduleEdges: ReadonlyArray<ModuleEdge>,
): Violation[] {
  // Type-only imports vanish at runtime, so they cannot create a runtime cycle.
  const out: Violation[] = [];

  if (rule.scope === "modules") {
    const edges = moduleEdges.filter((e) => !e.typeOnly);
    const nodes = input.constitution.modules.map((m) => m.id);
    const pairs = edges.map((e) => ({ from: e.fromModule, to: e.toModule }));
    for (const group of findCycles(nodes, pairs)) {
      const inGroup = new Set(group);
      const anchor = edges.find(
        (e) => inGroup.has(e.fromModule) && inGroup.has(e.toModule),
      );
      if (!anchor) continue;
      out.push({
        ruleId: rule.id,
        severity: rule.severity,
        message: `Modules depend on each other in a cycle: ${group.join(" <-> ")}.`,
        file: anchor.from,
        line: anchor.line,
        from: anchor.fromModule,
        to: anchor.toModule,
        fixHint:
          `Break the cycle between ${group.join(", ")}. For example, remove the import of "${anchor.specifier}" in ${anchor.from} (line ${anchor.line}), ` +
          `or move the shared code into a lower-level module that both depend on.`,
      });
    }
    return out;
  }

  const edges = input.edges.filter((e) => !e.typeOnly);
  for (const group of findCycles(
    input.files,
    edges.map((e) => ({ from: e.from, to: e.to })),
  )) {
    const inGroup = new Set(group);
    const anchor = edges
      .filter((e) => inGroup.has(e.from) && inGroup.has(e.to))
      .sort((a, b) => a.from.localeCompare(b.from) || a.line - b.line)[0];
    if (!anchor) continue;
    const m = (f: string) => input.fileModules[f] ?? undefined;
    const v: Violation = {
      ruleId: rule.id,
      severity: rule.severity,
      message: `Files import each other in a cycle: ${group.join(" <-> ")}.`,
      file: anchor.from,
      line: anchor.line,
      fixHint:
        `Break the cycle between these files: ${group.join(", ")}. For example, remove the import of "${anchor.specifier}" in ${anchor.from} (line ${anchor.line}), ` +
        `or move the shared code into a separate file that neither of them imports back.`,
    };
    const fm = m(anchor.from);
    const tm = m(anchor.to);
    if (fm) v.from = fm;
    if (tm) v.to = tm;
    out.push(v);
  }
  return out;
}

export function verify(input: VerifyInput, options: VerifyOptions = {}): CheckReport {
  const started = performance.now();
  const { constitution } = input;

  // Edges between two different modules (edges inside a module are fine).
  const moduleEdges: ModuleEdge[] = [];
  for (const e of input.edges) {
    const fromModule = input.fileModules[e.from] ?? null;
    const toModule = input.fileModules[e.to] ?? null;
    if (fromModule === null || toModule === null || fromModule === toModule) continue;
    moduleEdges.push({ ...e, fromModule, toModule });
  }

  const violations: Violation[] = [];
  for (const rule of constitution.rules) {
    if (rule.type === "deny") violations.push(...checkDeny(rule, moduleEdges));
    else if (rule.type === "allow-only") violations.push(...checkAllowOnly(rule, moduleEdges));
    else violations.push(...checkCycles(rule, input, moduleEdges));
  }
  violations.sort(bySeverityThenPlace);

  // An invariant is "verified" only if it points at rules we evaluated.
  const unverifiedInvariants = constitution.invariants
    .filter((i) => i.check?.type !== "rule-ref")
    .map((i) => i.id)
    .sort();

  return {
    constitutionVersion: 1,
    analyzedFiles: input.files.length,
    durationMs: options.durationMs ?? Math.round(performance.now() - started),
    violations,
    unverifiedInvariants,
  };
}

/** True when at least one violation has severity "error". */
export function hasErrors(report: CheckReport): boolean {
  return report.violations.some((v) => v.severity === "error");
}
